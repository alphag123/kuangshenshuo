create view i_i_view as
select `bookstore`.`item`.`itemid`    AS `itemid`,
       `bookstore`.`inventory`.`qty`  AS `qty`,
       `bookstore`.`item`.`listprice` AS `listprice`,
       `bookstore`.`item`.`attr5`     AS `attr5`
from (`bookstore`.`item`
         join `bookstore`.`inventory` on ((`bookstore`.`item`.`itemid` = `bookstore`.`inventory`.`itemid`)));

-- comment on column i_i_view.itemid not supported: 椤圭洰缂栧彿

-- comment on column i_i_view.listprice not supported: 瀹炵敤浠锋牸

