create view p_i_view as
select `bookstore`.`item`.`itemid`       AS `itemid`,
       `bookstore`.`product`.`productid` AS `productid`,
       `bookstore`.`product`.`name`      AS `name`,
       `bookstore`.`product`.`descn`     AS `descn`,
       `bookstore`.`item`.`listprice`    AS `listprice`
from (`bookstore`.`product`
         join `bookstore`.`item` on ((`bookstore`.`product`.`productid` = `bookstore`.`item`.`productid`)));

-- comment on column p_i_view.itemid not supported: 椤圭洰缂栧彿

-- comment on column p_i_view.listprice not supported: 瀹炵敤浠锋牸

